<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_client extends CI_Controller {

	public function edit_plan_list()
	{
		$planname = $this->input->post('txtPlanName');
		$planprice = $this->input->post('txtPlanPrice');
		$id = 	$this->input->post('id');
		$data = array(
			'plan_name' => $planname,
			'plan_price' => $planprice
			);

		$this->db->where('id',$id);
		$update_data = $this->db->update('plans',$data);
		if($update_data)
		{
				echo "<script>";
				echo "alert('Plan successfully Updated')";
				echo "</script>";
				$url = base_url().'index.php/admin_client/select_plan_list/';
	    		header("refresh:0.5;url=$url");
		}
		else
		{
				echo "<script>";
				echo "alert('Error in Updation')";
				echo "</script>";
				$url = base_url().'index.php/admin_client/select_plan_list/';
	    		header("refresh:0.5;url=$url");
		}
	}
	public function select_plan_list()
	{
		$this->load->view('select_plan_list');
	}
	public function select_client_list()
	{
		$this->load->view('select_client_list_view');
	}
	public function select_client_list_paid_invoice()
	{
		$this->load->view('select_client_list_view_paid_invoice');
	}
	public function select_client_list_due_invoice()
	{
		$this->load->view('select_client_list_view_due_invoice');
	}
	
	public function add_client(){
			$this->load->view('admin_add_client');
	}
	public function insert_client()
	{
		parse_str($_SERVER['QUERY_STRING'],$_REQUEST);
		if(isset($_POST['id']))
		{
				parse_str($_SERVER['QUERY_STRING'],$_REQUEST);
				$name = $this->input->post('txtName');
				$email = $this->input->post('txtEmail');
				$phonenumber = $this->input->post('txtPhoneNumber');
				$password = $this->input->post('txtPassword');
				$confirmpassword = $this->input->post('txtConfirmPassword');
				$plan = $this->input->post('txtPlan');
				$address = $this->input->post('txtDesc1');
				$id = $_POST['id'];

				if($password != $confirmpassword)
				{
					echo "<script>";
					echo "alert('Password Doesnot Match')";
					echo "</script>";
				}

				$data = array(
						'fname' => $name,
						'email' => $email,
						'mobile' => $phonenumber,
						'password' => $password,
						'plan_id' => $plan,
						'address' => $address
					);

				$this->db->where('id', $id);
				$update_data = $this->db->update('admin',$data);

				$this->load->view('admin_add_client');
		}
		else
		{
				$name = $this->input->post('txtName');
				$email = $this->input->post('txtEmail');
				$phonenumber = $this->input->post('txtPhoneNumber');
				$password = $this->input->post('txtPassword');
				$confirmpassword = $this->input->post('txtConfirmPassword');
				$plan = $this->input->post('txtPlan');
				$address = $this->input->post('txtDesc1');

				if($password != $confirmpassword)
				{
					echo "<script>";
					echo "alert('Password Doesnot Match')";
					echo "</script>";
					$this->load->view('admin_add_client');
				}
				else
				{
					$data = array(
							'fname' => $name,
							'email' => $email,
							'mobile' => $phonenumber,
							'password' => $password,
							'plan_id' => $plan,
							'address' => $address
						);
					$insert_data = $this->db->insert('admin',$data);
					if($insert_data)
					{
							echo "<script>";
							echo "alert('Client successfully Added')";
							echo "</script>";
							$url = base_url().'index.php/admin_client/select_client_list/';
				    		header("refresh:1;url=$url");
					}
					else
					{	
							echo "<script>";
							echo "Error in Insertion";
							echo "</script>";
					}	
				}
		}
	}
	public function select_user()
	{
		parse_str($_SERVER['QUERY_STRING'],$_REQUEST);
		$id = $_REQUEST['edit'];
		$result_client = $this->db->query("select * from admin where type='0' and id='$id'");
		$row_client = $result_client->result();
		$data = array(
			'email' => $row_client['0']->email,
			'fname' => $row_client['0']->fname,
			'lname' => $row_client['0']->lname,
			'password' => $row_client['0']->password,
			'mobile' => $row_client['0']->mobile,
			'plan' => $row_client['0']->plan,
			'address' => $row_client['0']->address,
			'id' => $row_client['0']->id
			);
		$this->load->view('admin_add_client',$data);		
	}
	public function remove_user()
	{
		$del_user = $this->db->query("delete from admin where id='".$_REQUEST['delete']."'");
			if($del_user)
			{
					echo "<script>";
					echo "alert('Client successfully Removed...!')";
					echo "</script>";
					$url = base_url().'index.php/admin_client/select_client_list/';
		    		header("refresh:0.5;url=$url");
			}
			else
			{	
					echo "<script>";
					echo "alert('Error in Deletion...!')";
					echo "</script>";
			}	
	}
}