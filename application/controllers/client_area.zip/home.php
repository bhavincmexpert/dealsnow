<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {
	public function test()
	{
			echo 'test';
	}
	public function index()
	{
			$this->load->view('header_client');
			$this->load->view('index');
			$this->load->view('footer_client');
	}
	public function admin()
	{
			$this->load->view('header_admin');
			$this->load->view('footer_admin');
	}
	public function login()
	{
			$this->load->view('login');
	}
	public function check_login()
	{
			parse_str($_SERVER['QUERY_STRING'],$_REQUEST);
			$user_email=$this->input->post('txtEmail');
    		$user_pass=$this->input->post('txtPassword');  

    		$result_login = $this->db->query("select * from admin where email='$user_email' and password='$user_pass'");
    		if($result_login -> num_rows > 0) 
    		{
		    		$row_login = $result_login->result();
		    		if($row_login['0']->type == '1')
		    		{
		    				//session start for admin
		    				$newdata = array(
								               'email_admin'     => $row_login['0']->email,
								               'id' 			 => $row_login['0']->id,
								               'logged_in' => TRUE
								           );
							$this->session->set_userdata($newdata);
		    				// Admin's Area
		    				$this->session->set_userdata('some_name', 'some_value');

		    				// $this->load->view('header_admin');
		    				// $this->load->view('index');
		    				// $this->load->view('footer_admin');
		    				redirect('home/index');
		    		}
		    		if($row_login['0']->type == '0')
		    		{
		    				//session start for client
		    				$newdata = array(
								               'email_client'     => $row_login['0']->email,
								               'id' 			  => $row_login['0']->id,
								               'logged_in' => TRUE
								           );
							$this->session->set_userdata($newdata);

		    				// client's Area
		    				redirect('home/index');
		    		}
		    }
		    else
		    {
		    		echo "<script>";
		    		echo "alert('User not Found');";
		    		echo "</script>";
		    		$url = base_url().'/index.php/home/login';
		    		header("refresh:3;url=$url");
		    }
	}

	public function change_password()
	{
		$this->load->view('change_password_admin');
	}
	public function change_password_client()
	{
		$this->load->view('change_password_client');
	}
	public function change_password_edit()
	{
		$currentpassword = $_POST['txtCurrentPassword'];
		$newpassword = $_POST['txtNewPassword'];
		$renewpassword = $_POST['txtRePassword'];
		$email =  $this->session->userdata('email_admin');
		$res_password =  $this->db->query("select * from admin where email='$email' and password='$currentpassword'");
		$row_password = $res_password->result();  
		if($res_password -> num_rows > 0)
		{
			// $this->db->set('password', $newpassword);
			// $this->db->where('id',$row_password['0']->password);
			// $this->db->update('admin');

			$update_password = $this->db->query("update admin set password='$newpassword' where email='$email'");
			if($update_password)
			{
					echo "<script>";
					echo "alert('password successfully changed');";
					echo "</script>";
					$url = base_url().'/index.php/home/change_password_client';
					header("refresh:2;url=$url");
			}	
			else
			{
					echo "<script>";
					echo "alert('Error in updation');";
					echo "</script>";
					$url = base_url().'/index.php/home/change_password_client';
					header("refresh:2;url=$url");
			}
		}
		else
		{
			echo "<script>";
			echo "alert('Current Password doesn't match');";
			echo "</script>";
			$url = base_url().'/index.php/home/change_password_client';
			header("refresh:;url=$url");
		}


		// $this->load->view('change_password_admin');
	}

	// public function logout()
	// {
	// 	$this->session->unset_userdata($session_data); 
 //        $this->session->sess_destroy();
 //        redirect('home/login');
	// }
	public function logout()
	{	
		echo 1;
		echo "<pre>";
		print_r($this->session->userdata);
		$this->session->sess_destroy();
		echo 2; 
		echo "<pre>";
		print_r($this->session->userdata);
		redirect('home/login');
	}
}