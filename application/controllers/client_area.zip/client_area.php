<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Client_area extends CI_Controller {

	
	public function edit_profile()
	{
		  $this->load->view('client_edit_profile');
	}

	public function restaurants()
	{
		$this->load->view('client_restaurants');
	}

	public function restaurants1()
	{
		$this->load->view('client_restaurants_test');
	}

	public function client_offers()
	{
		$this->load->view('client_offers');
	}
	
	public function select_business_cat1()
	{
		$result_cat1 =  $this->db->query("select * from category");
		$row_cat1 = $result_cat1->result();
		$data1 = array(
			'id' => $row_cat1['0']->id,
			'name' => $row_cat1['0']->name
			);
		$this->load->view('client_restaurants',$data1);
	}

	public function select_business_sub_cat()
	{
		$business1 = $this->input->post('business1');
		$result_sub_cat1 = $this->db->query("select category.id,subcategory.* From category LEFT JOIN subcategory ON category.id = subcategory.category_id where category.id = '$business1'");
		$row_cat1 = $result_sub_cat1->result();
		foreach($row_cat1 as $item)
		{
			// echo $row_cat1['0']->id;
			echo "<option value='" . $item->id . "'>" . $item->name . "</option>"; 	
		}
	}

	public function select_business_sub_sub_cat1()
	{
		$business2 = $this->input->post('business12');
		$result_sub_sub_cat1 = $this->db->query("select category.id,subcategory.*,sub_sub_category.* From category LEFT JOIN subcategory ON category.id = subcategory.category_id LEFT JOIN sub_sub_category ON sub_sub_category.id = subcategory.category_id where category.id = '$business2'");
		$row_sub_sub_cat1 = $result_sub_sub_cat1->result();
		foreach($row_sub_sub_cat1 as $item_sub)
		{
				echo "<option value='" . $item_sub->id . "'>" . $item_sub->name . "</option>";	
		}
	}
	public function image_remove()
	{
			$deleteid = $_REQUEST['del_id'];
			$delete_image = $this->db->query("delete from gallery_image where image_id='$deleteid'");
			if($delete_image)
			{
				echo "success";
			}			
	}
	public function image_remove_menu()
	{
			$deleteid = $_REQUEST['del_id'];
			$delete_image = $this->db->query("delete from menu_image where image_id='$deleteid'");
			if($delete_image)
			{
				echo "success";
			}	
	}
	public function offer_on_off()
	{
			$id = $this->input->post('id');
			echo $on_off = $this->input->post('on_off');
			$update_offer_primary = $this->db->query("update offers set primary_offer='$on_off' where id='$id'");
	}

	public function insert_business()
	{
			$name = $this->input->post('txtName');
			$email = $this->input->post('txtEmail');
			$phone = $this->input->post('txtPhone');
			$cousine = $this->input->post('txtCousine');
			$address = $this->input->post('txtAddress');
			$website = $this->input->post('txtWebsite');
			$facebook = $this->input->post('txtFacebook');
			$twitter = $this->input->post('txtTwitter');
			$business1 = $this->input->post('txtBusiness1');
			$business2 = $this->input->post('txtBusiness2');
			$business3 = $this->input->post('txtBusiness3');
			$business4 = $this->input->post('txtBusiness4');
			$adminid = $this->session->userdata('id');
			$data = array(
							'name' => $name,
							'email' => $email,
							'mobile' => $phone,
							'cousine' => $cousine,
							'address' => $address,
							'website' => $website,
							'facebook' => $facebook,
							'twitter' => $twitter,
							'category_id' => $business1,
							'subcategory_id' => $business2,
							'sub_sub_category_id' => $business4,
							'name' => $business3,
							'admin_id' => $adminid
							);
			$insert_data = $this->db->insert('information_business',$data);
			if($insert_data)
			{
					echo "<script>";
					echo "alert('Business successfully Added')";
					echo "</script>";
					$url = base_url().'/index.php/client_area/restaurants';
		    		header("refresh:1;url=$url");
			}
			else
			{
					echo "Error in Insertion";
			}	

	}
	public function insert_offer()
	{
			// Upload files Code starts Here
		          
            $image_name = $_FILES['userfile']['name'];
            $imagename = time().$image_name;
			$config =  array(
              'upload_path'     => "./public/image_offers",
              'allowed_types'   => "gif|jpg|png|jpeg|pdf",
              'overwrite'       => TRUE,
              'max_size'        => "2048000",  // Can be set to particular file size
              'max_height'      => "768",
              'max_width'       => "1024",
              'file_name'		=> $imagename
            );    
            $this->load->library('upload', $config);
			$this->upload->do_upload();
			$upload_data = $this->upload->data();
			$adminid = $this->session->userdata('id');

			// Upload files Code starts Here

			$name = $this->input->post('txtName');
			$image = $this->input->post('userfile');
			$desc = $this->input->post('txtDescription');
			$originalprice = $this->input->post('txtOriginalPrice');
			$offerprice = $this->input->post('txtOfferPrice');
			$start = $this->input->post('txtStart');
			$search = '-';
			$trimmed_start = str_replace($search, '', $start);
			$startdb =  date("Y-m-d H:i:s",strtotime($trimmed_start));
			$end = $this->input->post('txtEnd');
			$trimmed_end = str_replace($search, '', $end);
			$enddb = date("Y-m-d H:i:s",strtotime($trimmed_end));
			$business2 = $this->input->post('txtBusiness2');
			$business1 = $this->input->post('txtBusiness1');
			$data = array(
							'title' => $name,
							'description' => $desc,
							'image' => $imagename,
							'original_price' => $originalprice,
							'offer_price' => $offerprice,
							'start_date' => $startdb,
							'end_date' => $enddb,
							'category_id' => $business1,
							'subcategory_id' => $business2,
							'admin_id' => $adminid
							);
			$insert_data = $this->db->insert('offers',$data);

					if($insert_data)
					{
							echo "<script>";
							echo "alert('Offer successfully Added')";
							echo "</script>";
							$url = base_url().'/index.php/client_area/client_offers';
		    				header("refresh:1;url=$url");
					}
					else
					{
							echo "<script>";
							echo "alert('Error in Insertion of Offers')";
							echo "</script>";
					}
	}
	public function test()
	{
		$this->load->view('bootstrap_Test');
	}

	public function client_offers_list()
	{
		$this->load->view('client_offers_list');
	}
}

