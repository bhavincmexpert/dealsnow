<?php include('header_client.php'); 
		echo "Payment is cancelled"; 
?>
<?php include('footer_client.php'); ?>