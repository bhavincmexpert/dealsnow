<?php include('header_client.php'); 
?>
        <section class="vbox">          
        <section class="scrollable padder wrapper">   
        <section class="panel panel-default">      
            	<header class="panel-heading">
                        <span class="h4">List of Your Offers</span>
                </header>
        </section>
		<section class="panel panel-default">
					  <div class="adv-table">                 
					    <table class="display table table-bordered table-striped" id="example">
						      <thead>
						        <tr>
						          <th width="10%"> Offer Image </th> 
						          <th width="10%"> Title </th> 
						          <th width="20%"> Description </th> 
						          <th width="15%"> Start Date Time </th> 
						          <th width="15%"> End Date Time </th> 
						          <th width="10%"> Original Price </th> 
						          <th width="10%"> Offer Price </th> 
						          <th width="15%"> Primary Offer </th> 
						          <th width="15%"></th>
						          <th width="15%"></th> 
						        </tr>
						     </thead>
						     <?php
						     		$adminid = $this->session->userdata('id');
						     	 	$result_client = $this->db->query("select * from offers where admin_id='$adminid' order by id DESC");
						     		$row_client = $result_client->result();
						     		foreach($row_client as $row){
						     		?>
						       <tr class='gradeA'> 
						           <td><img width="200" height="200" src="<?php echo base_url(); ?>uploads/<?php echo $row->image; ?>"></td>
						       	   <td><?php echo $row->title; ?></td>
						       	   <td><?php echo $row->description; ?></td>
						       	   <td><?php echo $row->start_date; ?></td>
						       	   <td><?php echo $row->end_date; ?></td>
						       	   <td><?php echo $row->original_price; ?></td>
						       	   <td><?php echo $row->offer_price; ?></td>
				       	   		   <td> 
				       	   		 <script type="text/javascript">
									    $(document).on('change','#offer_dropdown',function(){
					         				var on_off = $('select#offer_dropdown option:selected').val();
					         				var id = <?php echo $row->id ?>;
				         				   $.ajax({
										   		type:"POST",
										   		data: { on_off:on_off,id:id },
										   		url: '<?php echo site_url('client_area/offer_on_off'); ?>',
										   		success : function (data)
										   		{
										   			if(data == '1')
										   			{
									   					alert('Primary Offers Successfully Added');
										   			}
										   			else
										   			{
										   				alert('Primary Offers Successfully Removed');
										   			}
										   		}
										   });
				         				   });
					  			</script>
								<div class="form-group">
					                    <label></label>
				        				<select name="" id="offer_dropdown" style="" class="">
										                 <option value="0"> OFF </option>
										                 <option value="1"> ON </option>
								        </select>                        
					             </div>								       	   		
						       	 </td>
					       	     <td><a href="<?php echo base_url(); ?>index.php/client_information/edit_client/?edit=<?php echo $row->id; ?>">
					       	    		<img src ="<?php echo base_url(); ?>/public/images/edit_new.png"/>
					       	    	</a>
			       	    		</td>
			       	    		<td><a href="<?php echo base_url(); ?>index.php/client_information/edit_client/?delete=<?php echo $row->id; ?>">
					       	    		<img src ="<?php echo base_url(); ?>/public/images/delete_new.png"/>
					       	    	</a>
			       	    		</td>
						      </tr>
						      <?php } ?>
					  	</table>	
					</div>                
			</section>
				</section>
			</section>

   <?php include('footer_client.php'); ?>
