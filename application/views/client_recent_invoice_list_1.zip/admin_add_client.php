<?php include('header_admin.php'); 
?>
      <section class="vbox">          
        <section class="scrollable padder wrapper">            
            <div class="row">
                <div class="col-sm-6">
                <form action="<?php echo base_url().'index.php/admin_client/insert_client/';  ?>" data-validate="parsley" enctype="multipart/form-data" method="post">
				<section class="panel panel-default">
                      <header class="panel-heading">
                        <span class="h4">ADD Client</span>
                      </header>
	             <div class="panel-body">
	                    <p class="text-muted">Please fill the information to continue</p>
	                    <div class="form-group">
	                      <label>First Name</label>
	                      <input type="text" name="txtName" value="" id="txtPlan" class="form-control" required="" />                        
	                    </div>
	                                           
	                   <div class="form-group">
	                      <label>Email Address </label>
	                      <input type="text" name="txtEmail"
	                             value="" id="txtPayment" class="form-control" required="" />                        
	                    </div>
	                    <div class="form-group">
	                      <label>Phone Number </label>
	                      <input type="text" name="txtPhoneNumber" 
	                             value="" id="txtPayment" class="form-control"  required="" />                        
	                    </div>
	                    <div class="form-group">
	                      <label>Password </label>
	                      <input type="password" name="txtPassword"
	                             value="" id="txtAmount" class="form-control"  required="" />                        
	                    </div>
	                    <div class="form-group">
	                      <label>Confirm Password</label>
	                      <input type="password" name="txtConfirmPassword"
	                             value="" id="txtAmount" class="form-control"  required="" />                        
	                    </div>
	                    <div class="form-group">
				                 <label > Plan </label> 
				                 <br/>
        				<select name="txtPlan" id="gender" style="height: 30px;width: 100%;" class="">
						                 <option value=""> Select Plan  </option>
               	 <?php 
               	 $result_cat1 =  $this->db->query("select * from plans");
				 $row_cat1 = $result_cat1->result();
               	 ?>
		        <?php foreach($row_cat1 as $item){ ?>
		        <option value="<?php echo $item->id; ?>"><?php echo $item->plan_name.'(Price :- '.$item->plan_price.')'; ?></option>
		        <?php } ?>
				        </select>
            			</div>
	                    <div class="form-group">
						  <label>Address</label>
						  <textarea class="form-control" id="txtDesc1" cols="66" rows="5.5" name="txtDesc1"                                    
						  placeholder="eg. Details about Hot Story"></textarea>
						</div>
	              </div>
	              <footer class="panel-footer text-right bg-light lter">
	                    <button type="submit" class="btn btn-success btn-s-xs">Submit</button>
	                    <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="mycancel" class="modal fade bs-example-modal-sm">
	                        <div class="modal-dialog modal-sm">
	                            <div class="modal-content">
	                                <div class="modal-header">
	                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
	                                    <h4 class="modal-title"><i class="fa fa-building-o"></i> Plan Insert Master Alert</h4>
	                                </div>
	                                <div class="modal-body">
	                                    <i class="fa fa-question-circle"></i> Are You Sure To Go Back!
	                                </div>
	                                <div class="modal-footer">                          
	                                    <input type='button' value='Yes' class="btn btn-success btn-shadow" onclick=""/>
	                                    <button data-dismiss="modal" class="btn btn-danger btn-shadow" type="button">No</button>
	                                </div>                      
	                            </div>
	                        </div>
	                    </div>
	<!--                        End Code for Cancle Alert-->
	                    <a href="" data-toggle='modal' class="btn btn-success btn-s-xs" name="cancel">Cancel</a>
	                  </footer>
                    </section>
                    </form>
                </div>
                </div>
				</section>
			</section>

   <?php include('footer_admin.php'); ?>
